#ifndef __DELAY_H
#define __DELAY_H 			   
#include "stdint.h"
void Delay_init(void);
void Delay_ms(uint16_t nms);
void Delay_us(int nus);

#endif





























